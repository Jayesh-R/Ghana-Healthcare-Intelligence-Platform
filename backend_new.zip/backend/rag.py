import faiss
import numpy as np
import sqlite3
import pickle
import os

DB_NAME = "healthcare.db"
INDEX_FILE = "hospital_index.faiss"
CHUNKS_FILE = "hospital_chunks.pkl"

# Lazy globals — nothing loads on import
_model = None
_index = None
_chunks = None

def get_model():
    global _model
    if _model is None:
        print("⏳ Loading embedding model...")
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer('all-MiniLM-L6-v2')
        print("✅ Model loaded")
    return _model

def build_index():
    print("🔨 Building RAG index...")
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT name, address_city, address_stateOrRegion,
               facilityTypeId, specialties, capability,
               procedure, equipment, description,
               numberDoctors, capacity
        FROM hospitals WHERE name IS NOT NULL
    """)
    rows = cursor.fetchall()
    conn.close()

    chunks = []
    texts = []
    for r in rows:
        text = f"""
        Hospital: {r['name']}
        Location: {r['address_city']}, {r['address_stateOrRegion']}
        Type: {r['facilityTypeId']}
        Specialties: {r['specialties']}
        Capabilities: {r['capability']}
        Procedures: {r['procedure']}
        Equipment: {r['equipment']}
        Description: {r['description']}
        """.strip()
        chunks.append({
            "text": text,
            "name": r['name'],
            "city": r['address_city'] or 'Unknown',
            "region": r['address_stateOrRegion'] or 'Unknown',
            "facilityType": r['facilityTypeId'],
            "specialties": r['specialties'],
            "capability": r['capability'],
        })
        texts.append(text)

    print(f"📝 Creating embeddings for {len(texts)} hospitals...")
    embeddings = get_model().encode(texts, show_progress_bar=False)
    embeddings = np.array(embeddings).astype('float32')
    faiss.normalize_L2(embeddings)

    dimension = embeddings.shape[1]
    index = faiss.IndexFlatIP(dimension)
    index.add(embeddings)

    faiss.write_index(index, INDEX_FILE)
    with open(CHUNKS_FILE, 'wb') as f:
        pickle.dump(chunks, f)

    print(f"✅ RAG index built with {len(chunks)} hospitals!")
    return index, chunks

def get_index():
    global _index, _chunks
    if _index is None:
        if os.path.exists(INDEX_FILE) and os.path.exists(CHUNKS_FILE):
            print("📂 Loading existing RAG index...")
            _index = faiss.read_index(INDEX_FILE)
            with open(CHUNKS_FILE, 'rb') as f:
                _chunks = pickle.load(f)
            print(f"✅ Loaded {len(_chunks)} hospitals")
        else:
            _index, _chunks = build_index()
    return _index, _chunks

def semantic_search(query: str, k: int = 5):
    index, chunks = get_index()
    query_embedding = get_model().encode([query])
    query_embedding = np.array(query_embedding).astype('float32')
    faiss.normalize_L2(query_embedding)
    scores, indices = index.search(query_embedding, k)
    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx < len(chunks):
            chunk = chunks[idx].copy()
            chunk['score'] = float(score)
            results.append(chunk)
    return results